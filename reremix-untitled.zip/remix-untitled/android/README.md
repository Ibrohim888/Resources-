# Native Android Application (Kotlin & Jetpack Compose)

Ushbu katalogda **O'quv Markaz Homework & Rating System** loyihasining to'liq native **Android Kotlin (Jetpack Compose + Material 3 + Firebase Firestore)** manba kodi (source code) joylashgan.

## 🚀 Qanday qilib Android Studio'da ochish va APK build qilish:

1. **Loyiha fayllarini yuklab olish (Export):**
   - AI Studio yuqori o'ng burchagidagi **Settings -> Export Code / Download ZIP** orqali loyihani kompyuteringizga yuklab oling.

2. **Android Studio'da ochish:**
   - Android Studio drayverini oching (Electric Eel / Giraffe / Hedgehog yoki undan yangi versiyasi).
   - **Open an existing project** tugmasini bosing va ushbu loyihaning `android` papkasini tanlang.

3. **Gradle Sync:**
   - Android Studio avtomatik ravishda barcha Android SDK va Jetpack Compose bog'liqliklarini (dependencies) yuklab oladi va sinxronlaydi.

4. **APK Build qilish:**
   - **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** menyusini bosing.
   - Yaratilgan `.apk` faylini istalgan Android telefonga o'rnatishingiz mumkin!

## 📁 Native Android Kodlarining Tuzilishi (Kotlin):

- `android/app/src/main/java/com/ouqivmarkaz/homeworkmanager/MainActivity.kt`: Jetpack Compose Material 3 asosiy oynasi va navigatsiya.
- `android/app/src/main/java/com/ouqivmarkaz/homeworkmanager/model/Models.kt`: Student, Homework, Result, TeacherProfile va Rating ma'lumotlar modellari.
- `android/app/src/main/java/com/ouqivmarkaz/homeworkmanager/data/FirebaseRepository.kt`: Firebase Firestore bazasi bilan real-vaqt rejimida sinxronizatsiya va 3 tildagi hisobot generatori.
- `android/app/src/main/java/com/ouqivmarkaz/homeworkmanager/data/PreferencesManager.kt`: SharedPreferences/Gson local storage kesh tizimi.
- `android/app/src/main/java/com/ouqivmarkaz/homeworkmanager/ui/viewmodel/MainViewModel.kt`: MVVM arxitektura va holat boshqaruvi (StateFlow).
- `android/app/src/main/java/com/ouqivmarkaz/homeworkmanager/ui/screens/`:
  - `HomeScreen.kt`: Statistikalar va top reytinglar dashboard'i.
  - `StudentsScreen.kt`: O'quvchilarni boshqarish, 8 xonali ID va Maxfiy kod yaratish.
  - `HomeworksScreen.kt`: Uy vazifalarini yaratish va guruhlarga biriktirish.
  - `GradingScreen.kt`: O'quvchilarni darsda bor/yo'qligi (NB) va baholarini qo'yish.
  - `RatingScreen.kt`: Oylik reyting va liderlar jadvali.
  - `SettingsScreen.kt`: Markaz va o'qituvchi profil sozlamalari.
