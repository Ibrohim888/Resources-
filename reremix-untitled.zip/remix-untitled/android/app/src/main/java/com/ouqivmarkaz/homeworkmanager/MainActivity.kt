package com.ouqivmarkaz.homeworkmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.ouqivmarkaz.homeworkmanager.ui.screens.*
import com.ouqivmarkaz.homeworkmanager.ui.theme.HomeworkManagerTheme
import com.ouqivmarkaz.homeworkmanager.ui.viewmodel.MainViewModel

sealed class NavigationItem(val route: String, val title: String, val icon: ImageVector) {
    object Home : NavigationItem("home", "Bosh sahifa", Icons.Default.Home)
    object Students : NavigationItem("students", "O'quvchilar", Icons.Default.People)
    object Homeworks : NavigationItem("homeworks", "Vazifalar", Icons.Default.Assignment)
    object Rating : NavigationItem("rating", "Reyting", Icons.Default.EmojiEvents)
    object Settings : NavigationItem("settings", "Sozlamalar", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    private val mainViewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            HomeworkManagerTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val bottomBarItems = listOf(
                    NavigationItem.Home,
                    NavigationItem.Students,
                    NavigationItem.Homeworks,
                    NavigationItem.Rating,
                    NavigationItem.Settings
                )

                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Text(
                                    when {
                                        currentRoute == "home" -> "Homework Manager"
                                        currentRoute == "students" -> "O'quvchilar Boshqaruvi"
                                        currentRoute == "homeworks" -> "Vazifalar Boshqaruvi"
                                        currentRoute == "rating" -> "Reyting va Hisobot"
                                        currentRoute == "settings" -> "Profil va Sozlamalar"
                                        currentRoute?.startsWith("grading/") == true -> "O'quvchilarni Baholash"
                                        else -> "Homework Manager"
                                    }
                                )
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    },
                    bottomBar = {
                        if (currentRoute != null && !currentRoute.startsWith("grading/")) {
                            NavigationBar {
                                bottomBarItems.forEach { item ->
                                    NavigationBarItem(
                                        icon = { Icon(item.icon, contentDescription = item.title) },
                                        label = { Text(item.title) },
                                        selected = currentRoute == item.route,
                                        onClick = {
                                            if (currentRoute != item.route) {
                                                navController.navigate(item.route) {
                                                    popUpTo(navController.graph.startDestinationId) {
                                                        saveState = true
                                                    }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = NavigationItem.Home.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(NavigationItem.Home.route) {
                            HomeScreen(viewModel = mainViewModel, onNavigate = { route -> navController.navigate(route) })
                        }
                        composable(NavigationItem.Students.route) {
                            StudentsScreen(viewModel = mainViewModel)
                        }
                        composable(NavigationItem.Homeworks.route) {
                            HomeworksScreen(
                                viewModel = mainViewModel,
                                onEvaluateHomework = { hwId -> navController.navigate("grading/$hwId") }
                            )
                        }
                        composable("grading/{homeworkId}") { backStackEntry ->
                            val homeworkId = backStackEntry.arguments?.getString("homeworkId") ?: ""
                            GradingScreen(
                                homeworkId = homeworkId,
                                viewModel = mainViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(NavigationItem.Rating.route) {
                            RatingScreen(viewModel = mainViewModel)
                        }
                        composable(NavigationItem.Settings.route) {
                            SettingsScreen(viewModel = mainViewModel)
                        }
                    }
                }
            }
        }
    }
}
