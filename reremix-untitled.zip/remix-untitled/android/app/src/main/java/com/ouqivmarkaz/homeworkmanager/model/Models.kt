package com.ouqivmarkaz.homeworkmanager.model

import java.util.UUID

enum class AppLanguage { UZ, RU, EN }

enum class ThemeColor { FOREST_GREEN, TRUST_BLUE, VIOLET, WARM_ROSE, TEAL }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class HomeworkStatus { DRAFT, ACTIVE, COMPLETED, ARCHIVED }

enum class ResultStatus { COMPLETED, PARTIAL, MISSING }

enum class GradeType { PERCENT, POINT_10 }

data class Student(
    val id: String = UUID.randomUUID().toString(),
    val studentIdNumber: String = "", // 8-digit numeric ID, e.g. "84920184"
    val secretCode: String = "",      // 8-char mixed alphanumeric, e.g. "TX78B2A9"
    val firstName: String = "",
    val lastName: String = "",
    val fullName: String = "",
    val classNames: List<String> = emptyList(), // e.g. ["7-A", "Olimpiada"]
    val phone: String? = null,
    val notes: String? = null,
    val photo: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
)

data class Homework(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val subject: String = "",
    val className: String = "", // Target group
    val description: String = "",
    val attachmentName: String? = null,
    val attachmentURL: String? = null,
    val assignedDate: String = "",
    val deadline: String = "",
    val status: HomeworkStatus = HomeworkStatus.ACTIVE,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class Result(
    val id: String = UUID.randomUUID().toString(),
    val studentId: String = "",
    val homeworkId: String = "",
    val isPresent: Boolean = true, // Attendance: true = Present, false = Absent (NB)
    val completionStatus: ResultStatus = ResultStatus.COMPLETED,
    val grade: Float? = null,
    val gradeType: GradeType = GradeType.POINT_10,
    val comment: String? = null,
    val checkedDate: Long = System.currentTimeMillis(),
    val checkedBy: String = "Teacher"
)

data class TeacherProfile(
    val fullName: String = "O'qituvchi",
    val email: String = "teacher@center.uz",
    val centerName: String = "O'quv Markazi",
    val profileImage: String? = null,
    val language: AppLanguage = AppLanguage.UZ,
    val themeColor: ThemeColor = ThemeColor.TRUST_BLUE,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val darkMode: Boolean = false,
    val ratingStartDate: Int = 1,
    val isFirstLaunchCompleted: Boolean = true
)

data class StudentRanking(
    val studentId: String = "",
    val studentName: String = "",
    val studentIdNumber: String = "",
    val secretCode: String = "",
    val classNames: List<String> = emptyList(),
    val avgGrade: Float = 0f,
    val completionRate: Int = 0,
    val totalSubmitted: Int = 0
)

data class MonthlyArchive(
    val id: String = UUID.randomUUID().toString(),
    val monthLabel: String = "",
    val archivedAt: Long = System.currentTimeMillis(),
    val rankings: List<StudentRanking> = emptyList()
)
