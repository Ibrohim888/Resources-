package com.ouqivmarkaz.homeworkmanager.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF2563EB)
val BlueSecondary = Color(0xFF3B82F6)
val BlueBackground = Color(0xFFF8FAFC)
val CardBackground = Color(0xFFFFFFFF)
val TextDark = Color(0xFF0F172A)
val TextMuted = Color(0xFF64748B)

val GreenSuccess = Color(0xFF10B981)
val RedDanger = Color(0xFFEF4444)
val AmberWarning = Color(0xFFF59E0B)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkText = Color(0xFFF8FAFC)
