package com.ouqivmarkaz.homeworkmanager.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.ouqivmarkaz.homeworkmanager.data.FirebaseRepository
import com.ouqivmarkaz.homeworkmanager.data.PreferencesManager
import com.ouqivmarkaz.homeworkmanager.model.Homework
import com.ouqivmarkaz.homeworkmanager.model.MonthlyArchive
import com.ouqivmarkaz.homeworkmanager.model.Result
import com.ouqivmarkaz.homeworkmanager.model.Student
import com.ouqivmarkaz.homeworkmanager.model.StudentRanking
import com.ouqivmarkaz.homeworkmanager.model.TeacherProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = PreferencesManager(application)
    private val firebaseRepo = FirebaseRepository()

    private val _profile = MutableStateFlow(prefs.getProfile())
    val profile: StateFlow<TeacherProfile> = _profile.asStateFlow()

    private val _students = MutableStateFlow(prefs.getStudents())
    val students: StateFlow<List<Student>> = _students.asStateFlow()

    private val _homeworks = MutableStateFlow(prefs.getHomeworks())
    val homeworks: StateFlow<List<Homework>> = _homeworks.asStateFlow()

    private val _results = MutableStateFlow(prefs.getResults())
    val results: StateFlow<List<Result>> = _results.asStateFlow()

    private val _archives = MutableStateFlow(prefs.getArchives())
    val archives: StateFlow<List<MonthlyArchive>> = _archives.asStateFlow()

    init {
        syncAllToFirebase()
    }

    // --- Student Actions ---
    fun addStudent(fullName: String, classNames: List<String>, phone: String?, notes: String?) {
        val parts = fullName.trim().split(" ")
        val fName = parts.getOrNull(0) ?: ""
        val lName = parts.drop(1).joinToString(" ")
        
        val newStudent = Student(
            studentIdNumber = generate8DigitId(),
            secretCode = generateSecretCode(),
            firstName = fName,
            lastName = lName,
            fullName = fullName,
            classNames = classNames,
            phone = phone,
            notes = notes
        )
        val updated = _students.value + newStudent
        _students.value = updated
        prefs.saveStudents(updated)
        firebaseRepo.syncStudents(updated)
        syncReport3Languages()
    }

    fun deleteStudent(studentId: String) {
        val updated = _students.value.filter { it.id != studentId }
        _students.value = updated
        prefs.saveStudents(updated)
        firebaseRepo.syncStudents(updated)
        syncReport3Languages()
    }

    // --- Homework Actions ---
    fun addHomework(title: String, subject: String, className: String, description: String, deadline: String) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val newHw = Homework(
            title = title,
            subject = subject,
            className = className,
            description = description,
            assignedDate = today,
            deadline = deadline
        )
        val updated = _homeworks.value + newHw
        _homeworks.value = updated
        prefs.saveHomeworks(updated)
        firebaseRepo.syncHomeworks(updated)
        syncReport3Languages()
    }

    // --- Evaluation / Grading Actions ---
    fun saveResult(result: Result) {
        val current = _results.value.filter { !(it.studentId == result.studentId && it.homeworkId == result.homeworkId) }
        val updated = current + result
        _results.value = updated
        prefs.saveResults(updated)
        firebaseRepo.syncResults(updated)
        syncReport3Languages()
    }

    // --- Profile Actions ---
    fun updateProfile(newProfile: TeacherProfile) {
        _profile.value = newProfile
        prefs.saveProfile(newProfile)
        firebaseRepo.syncProfile(newProfile)
        syncReport3Languages()
    }

    // --- Report Calculation & Firebase Sync ---
    fun getRankings(): List<StudentRanking> {
        val activeSt = _students.value.filter { it.isActive }
        val allResults = _results.value

        return activeSt.map { student ->
            val stResults = allResults.filter { it.studentId == student.id }
            val totalCount = stResults.size
            val completedCount = stResults.count { it.completionStatus.name == "COMPLETED" }
            val compRate = if (totalCount > 0) ((completedCount.toFloat() / totalCount) * 100).toInt() else 0

            val validGrades = stResults.mapNotNull { it.grade }
            val rawAvg = if (validGrades.isNotEmpty()) validGrades.average().toFloat() else 0f
            val normalizedAvg = if (rawAvg > 10f) rawAvg / 10f else rawAvg

            StudentRanking(
                studentId = student.id,
                studentName = student.fullName,
                studentIdNumber = student.studentIdNumber,
                secretCode = student.secretCode,
                classNames = student.classNames,
                avgGrade = normalizedAvg,
                completionRate = compRate,
                totalSubmitted = completedCount
            )
        }.sortedWith(compareByDescending<StudentRanking> { it.avgGrade }.thenByDescending { it.completionRate })
    }

    private fun syncReport3Languages() {
        val currentMonth = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())
        val rankings = getRankings()
        val prof = _profile.value

        firebaseRepo.syncReport3Languages(
            monthLabel = currentMonth,
            centerName = prof.centerName,
            teacherName = prof.fullName,
            studentsCount = _students.value.count { it.isActive },
            homeworksCount = _homeworks.value.size,
            rankings = rankings
        )
    }

    private fun syncAllToFirebase() {
        firebaseRepo.syncProfile(_profile.value)
        firebaseRepo.syncStudents(_students.value)
        firebaseRepo.syncHomeworks(_homeworks.value)
        firebaseRepo.syncResults(_results.value)
        syncReport3Languages()
    }

    private fun generate8DigitId(): String {
        return (10000000..99999999).random().toString()
    }

    private fun generateSecretCode(): String {
        val charPool = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..8)
            .map { Random.nextInt(0, charPool.length) }
            .map(charPool::get)
            .joinToString("")
    }
}
