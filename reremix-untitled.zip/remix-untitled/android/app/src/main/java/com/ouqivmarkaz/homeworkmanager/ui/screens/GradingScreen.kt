package com.ouqivmarkaz.homeworkmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ouqivmarkaz.homeworkmanager.model.GradeType
import com.ouqivmarkaz.homeworkmanager.model.Result
import com.ouqivmarkaz.homeworkmanager.model.ResultStatus
import com.ouqivmarkaz.homeworkmanager.ui.viewmodel.MainViewModel

@Composable
fun GradingScreen(
    homeworkId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val homeworks by viewModel.homeworks.collectAsState()
    val students by viewModel.students.collectAsState()
    val results by viewModel.results.collectAsState()

    val homework = homeworks.find { it.id == homeworkId } ?: return

    val targetStudents = students.filter { student ->
        student.classNames.contains(homework.className) || homework.className == "Barchasi"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Orqaga")
            }
            Column {
                Text(
                    text = homework.title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Guruh: ${homework.className} | Fan: ${homework.subject}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(targetStudents, key = { it.id }) { student ->
                val existingResult = results.find { it.studentId == student.id && it.homeworkId == homework.id }
                StudentGradingCard(
                    studentName = student.fullName,
                    studentIdNumber = student.studentIdNumber,
                    existingResult = existingResult,
                    onSaveResult = { isPresent, grade, status, comment ->
                        viewModel.saveResult(
                            Result(
                                id = existingResult?.id ?: java.util.UUID.randomUUID().toString(),
                                studentId = student.id,
                                homeworkId = homework.id,
                                isPresent = isPresent,
                                completionStatus = status,
                                grade = grade,
                                gradeType = GradeType.POINT_10,
                                comment = comment
                            )
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun StudentGradingCard(
    studentName: String,
    studentIdNumber: String,
    existingResult: Result?,
    onSaveResult: (Boolean, Float?, ResultStatus, String?) -> Unit
) {
    var isPresent by remember(existingResult) { mutableStateOf(existingResult?.isPresent ?: true) }
    var gradeText by remember(existingResult) { mutableStateOf(existingResult?.grade?.toString() ?: "10") }
    var comment by remember(existingResult) { mutableStateOf(existingResult?.comment ?: "") }
    var status by remember(existingResult) { mutableStateOf(existingResult?.completionStatus ?: ResultStatus.COMPLETED) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = studentName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(text = "ID: $studentIdNumber", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                }

                FilterChip(
                    selected = !isPresent,
                    onClick = { isPresent = !isPresent },
                    label = { Text(if (isPresent) "Darsda bor" else "NB (Kelmagan)") }
                )
            }

            if (isPresent) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = gradeText,
                        onValueChange = { gradeText = it },
                        label = { Text("Baho (1-10)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = comment,
                        onValueChange = { comment = it },
                        label = { Text("Izoh (Ixtiyoriy)") },
                        modifier = Modifier.weight(2f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = {
                    val floatGrade = if (isPresent) gradeText.toFloatOrNull() ?: 0f else null
                    onSaveResult(isPresent, floatGrade, status, comment.ifBlank { null })
                },
                modifier = Modifier.align(Alignment.End)
            ) {
                Icon(Icons.Default.Save, contentDescription = "Saqlash")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Bahoni Saqlash")
            }
        }
    }
}
