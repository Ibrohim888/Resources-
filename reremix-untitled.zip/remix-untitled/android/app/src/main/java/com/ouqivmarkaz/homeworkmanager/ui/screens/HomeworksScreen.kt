package com.ouqivmarkaz.homeworkmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ouqivmarkaz.homeworkmanager.ui.viewmodel.MainViewModel

@Composable
fun HomeworksScreen(viewModel: MainViewModel, onEvaluateHomework: (String) -> Unit) {
    val homeworks by viewModel.homeworks.collectAsState()
    var showAddModal by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Vazifalar Ro'yxati",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(homeworks, key = { it.id }) { homework ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = homework.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                                    Text(homework.className, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Fan: ${homework.subject} | Muddat: ${homework.deadline}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = homework.description, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { onEvaluateHomework(homework.id) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Baholash")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("O'quvchilarni Baholash va Tekshirish")
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showAddModal = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp),
            containerColor = MaterialTheme.colorScheme.primary
        ) {
            Icon(Icons.Default.Add, contentDescription = "Yangi Vazifa", tint = MaterialTheme.colorScheme.onPrimary)
        }
    }

    if (showAddModal) {
        AddHomeworkDialog(
            onDismiss = { showAddModal = false },
            onConfirm = { title, subject, group, desc, deadline ->
                viewModel.addHomework(title, subject, group, desc, deadline)
                showAddModal = false
            }
        )
    }
}

@Composable
fun AddHomeworkDialog(onDismiss: () -> Unit, onConfirm: (String, String, String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var deadline by remember { mutableStateOf("2026-08-10") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yangi Vazifa Yaratish") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Vazifa Mavzusi / Sarlavhasi") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Fan nomi (Masalan: Matematika)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = group,
                    onValueChange = { group = it },
                    label = { Text("Maqsadli Sinf / Guruh (Masalan: 7-A)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Tavsif / Topshiriq matni") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = deadline,
                    onValueChange = { deadline = it },
                    label = { Text("Topshirish muddati (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (title.isNotBlank() && subject.isNotBlank() && group.isNotBlank()) onConfirm(title, subject, group, desc, deadline) },
                enabled = title.isNotBlank() && subject.isNotBlank() && group.isNotBlank()
            ) {
                Text("Saqlash")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Bekor qilish") }
        }
    )
}
