package com.ouqivmarkaz.homeworkmanager.data

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.ouqivmarkaz.homeworkmanager.model.Homework
import com.ouqivmarkaz.homeworkmanager.model.MonthlyArchive
import com.ouqivmarkaz.homeworkmanager.model.Result
import com.ouqivmarkaz.homeworkmanager.model.Student
import com.ouqivmarkaz.homeworkmanager.model.StudentRanking
import com.ouqivmarkaz.homeworkmanager.model.TeacherProfile

class FirebaseRepository {
    private val firestore by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e("FirebaseRepository", "Firebase not initialized: ${e.message}")
            null
        }
    }

    fun syncStudents(students: List<Student>) {
        val db = firestore ?: return
        students.forEach { student ->
            db.collection("students").document(student.id)
                .set(student, SetOptions.merge())
                .addOnFailureListener { Log.e("Firebase", "Failed to sync student: ${it.message}") }
        }
    }

    fun syncHomeworks(homeworks: List<Homework>) {
        val db = firestore ?: return
        homeworks.forEach { homework ->
            db.collection("homeworks").document(homework.id)
                .set(homework, SetOptions.merge())
                .addOnFailureListener { Log.e("Firebase", "Failed to sync homework: ${it.message}") }
        }
    }

    fun syncResults(results: List<Result>) {
        val db = firestore ?: return
        results.forEach { result ->
            db.collection("results").document(result.id)
                .set(result, SetOptions.merge())
                .addOnFailureListener { Log.e("Firebase", "Failed to sync result: ${it.message}") }
        }
    }

    fun syncProfile(profile: TeacherProfile) {
        val db = firestore ?: return
        db.collection("profiles").document("teacher_main")
            .set(profile, SetOptions.merge())
            .addOnFailureListener { Log.e("Firebase", "Failed to sync profile: ${it.message}") }
    }

    fun syncReport3Languages(
        monthLabel: String,
        centerName: String,
        teacherName: String,
        studentsCount: Int,
        homeworksCount: Int,
        rankings: List<StudentRanking>
    ) {
        val db = firestore ?: return

        // Multi-language reports format for Student App
        val reportUz = mapOf(
            "title" to "$monthLabel oylik hisoboti",
            "center" to centerName,
            "teacher" to teacherName,
            "summary" to "Faol o'quvchilar: $studentsCount, Jami topshiriqlar: $homeworksCount"
        )
        val reportRu = mapOf(
            "title" to "Ежемесячный отчет за $monthLabel",
            "center" to centerName,
            "teacher" to teacherName,
            "summary" to "Активные студенты: $studentsCount, Всего заданий: $homeworksCount"
        )
        val reportEn = mapOf(
            "title" to "Monthly report for $monthLabel",
            "center" to centerName,
            "teacher" to teacherName,
            "summary" to "Active students: $studentsCount, Total homeworks: $homeworksCount"
        )

        val docData = hashMapOf(
            "id" to "latest_report",
            "monthLabel" to monthLabel,
            "updatedAt" to System.currentTimeMillis(),
            "centerName" to centerName,
            "teacherName" to teacherName,
            "studentsCount" to studentsCount,
            "homeworksCount" to homeworksCount,
            "rankings" to rankings,
            "reports" to mapOf(
                "uz" to reportUz,
                "ru" to reportRu,
                "en" to reportEn
            )
        )

        db.collection("reports").document("latest_report")
            .set(docData, SetOptions.merge())
            .addOnSuccessListener { Log.d("Firebase", "3-language report synced successfully!") }
            .addOnFailureListener { Log.e("Firebase", "Failed 3-language report sync: ${it.message}") }
    }
}
