package com.ouqivmarkaz.homeworkmanager.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.ouqivmarkaz.homeworkmanager.model.Homework
import com.ouqivmarkaz.homeworkmanager.model.MonthlyArchive
import com.ouqivmarkaz.homeworkmanager.model.Result
import com.ouqivmarkaz.homeworkmanager.model.Student
import com.ouqivmarkaz.homeworkmanager.model.TeacherProfile

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("homework_manager_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getProfile(): TeacherProfile {
        val json = prefs.getString("profile", null) ?: return TeacherProfile()
        return try { gson.fromJson(json, TeacherProfile::class.java) } catch (e: Exception) { TeacherProfile() }
    }

    fun saveProfile(profile: TeacherProfile) {
        prefs.edit().putString("profile", gson.toJson(profile)).apply()
    }

    fun getStudents(): List<Student> {
        val json = prefs.getString("students", null) ?: return defaultStudents()
        val type = object : TypeToken<List<Student>>() {}.type
        return try { gson.fromJson(json, type) } catch (e: Exception) { defaultStudents() }
    }

    fun saveStudents(students: List<Student>) {
        prefs.edit().putString("students", gson.toJson(students)).apply()
    }

    fun getHomeworks(): List<Homework> {
        val json = prefs.getString("homeworks", null) ?: return defaultHomeworks()
        val type = object : TypeToken<List<Homework>>() {}.type
        return try { gson.fromJson(json, type) } catch (e: Exception) { defaultHomeworks() }
    }

    fun saveHomeworks(homeworks: List<Homework>) {
        prefs.edit().putString("homeworks", gson.toJson(homeworks)).apply()
    }

    fun getResults(): List<Result> {
        val json = prefs.getString("results", null) ?: return emptyList()
        val type = object : TypeToken<List<Result>>() {}.type
        return try { gson.fromJson(json, type) } catch (e: Exception) { emptyList() }
    }

    fun saveResults(results: List<Result>) {
        prefs.edit().putString("results", gson.toJson(results)).apply()
    }

    fun getArchives(): List<MonthlyArchive> {
        val json = prefs.getString("archives", null) ?: return emptyList()
        val type = object : TypeToken<List<MonthlyArchive>>() {}.type
        return try { gson.fromJson(json, type) } catch (e: Exception) { emptyList() }
    }

    fun saveArchives(archives: List<MonthlyArchive>) {
        prefs.edit().putString("archives", gson.toJson(archives)).apply()
    }

    private fun defaultStudents(): List<Student> {
        return listOf(
            Student(id = "st-1", studentIdNumber = "84920184", secretCode = "TX78B2A9", firstName = "Anvar", lastName = "Karimov", fullName = "Anvar Karimov", classNames = listOf("7-A", "Matematika")),
            Student(id = "st-2", studentIdNumber = "91204812", secretCode = "KL91A3X0", firstName = "Malika", lastName = "Saitova", fullName = "Malika Saitova", classNames = listOf("7-A", "Fizika")),
            Student(id = "st-3", studentIdNumber = "73019284", secretCode = "MN82C4Z7", firstName = "Jasur", lastName = "Sobirov", fullName = "Jasur Sobirov", classNames = listOf("8-B", "Ingliz tili"))
        )
    }

    private fun defaultHomeworks(): List<Homework> {
        return listOf(
            Homework(id = "hw-1", title = "Kvadrat tenglamalarni yechish", subject = "Matematika", className = "7-A", description = "Darslikning 42-betidagi 1-10 misollarni yechish", assignedDate = "2026-08-01", deadline = "2026-08-05"),
            Homework(id = "hw-2", title = "Newton qonunlari tajribalari", subject = "Fizika", className = "7-A", description = "Ishqalanish kuchiga doir tajriba hisobotini yozish", assignedDate = "2026-08-02", deadline = "2026-08-06")
        )
    }
}
