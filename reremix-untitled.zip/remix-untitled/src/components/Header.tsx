import React, { useState } from 'react';
import { TeacherProfile } from '../types';
import { themeConfigs } from '../lib/theme';
import { getTranslation } from '../lib/translations';
import {
  MoreVertical,
  Wifi,
  LogOut,
  Settings,
  User,
  Share2,
  Building,
  Sun,
  Moon
} from 'lucide-react';

interface HeaderProps {
  profile: TeacherProfile;
  onUpdateProfile: (updated: Partial<TeacherProfile>) => void;
  onOpenProfile: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  onUpdateProfile,
  onOpenProfile,
}) => {
  const [showOverflow, setShowOverflow] = useState(false);

  const activeTheme = themeConfigs[profile.themeColor] || themeConfigs['forest_green'];

  const toggleDarkMode = () => {
    const isDarkNow = document.documentElement.classList.contains('dark');
    if (isDarkNow) {
      onUpdateProfile({ themeMode: 'light', darkMode: false });
    } else {
      onUpdateProfile({ themeMode: 'dark', darkMode: true });
    }
  };

  return (
    <header
      className="sticky top-0 z-30 text-white py-3.5 px-4 sm:px-6 shadow-md transition-all duration-300"
      style={{
        background: `linear-gradient(135deg, ${activeTheme.primary}, ${activeTheme.gradientEnd})`,
      }}
    >
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Teacher Info & Center Name */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenProfile}
            className="relative group focus:outline-none"
            title="Profilni ochish"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white font-bold text-base sm:text-lg shadow-inner border border-white/30 group-hover:scale-105 transition-transform">
              {profile.fullName ? profile.fullName.charAt(0).toUpperCase() : 'O'}
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-white" />
          </button>

          <div>
            <h1 className="font-display font-bold text-base sm:text-lg tracking-tight leading-none text-white">
              {profile.fullName || "O'qituvchi"}
            </h1>
            <div className="flex items-center gap-1.5 text-xs text-white/80 mt-1">
              <Building className="w-3.5 h-3.5" />
              <span className="truncate max-w-[160px] sm:max-w-[240px]">
                {profile.centerName || 'O\'quv Markazi'}
              </span>
            </div>
          </div>
        </div>

        {/* Right Actions: Sync Badge, Dark/Light Mode Toggle, Settings */}
        <div className="flex items-center gap-2">
          {/* Sync Badge */}
          <div className="hidden sm:flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3 py-1.5 rounded-full text-xs font-medium border border-white/20">
            <Wifi className="w-3.5 h-3.5 text-emerald-300" />
            <span>{getTranslation(profile.language, 'syncStatus')}</span>
          </div>

          {/* Quick Dark / Light Mode Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-2.5 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 transition-colors focus:outline-none min-h-[44px] min-w-[44px] flex items-center justify-center text-white"
            title={profile.darkMode ? "Yorug' rejimga o'tish" : "Tungi rejimga o'tish"}
          >
            {profile.darkMode ? (
              <Sun className="w-5 h-5 text-amber-300 animate-fadeIn" />
            ) : (
              <Moon className="w-5 h-5 text-indigo-100 animate-fadeIn" />
            )}
          </button>

          {/* Settings / Profile Button */}
          <button
            onClick={onOpenProfile}
            className="p-2.5 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 transition-colors focus:outline-none min-h-[44px] min-w-[44px] flex items-center justify-center text-white"
            title="Sozlamalar"
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* Overflow Menu (⋮) */}
          <div className="relative">
            <button
              onClick={() => setShowOverflow(!showOverflow)}
              className="p-2.5 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 transition-colors focus:outline-none min-h-[44px] min-w-[44px] flex items-center justify-center text-white"
              title="Qo'shimcha"
            >
              <MoreVertical className="w-5 h-5" />
            </button>

            {/* Overflow Dropdown */}
            {showOverflow && (
              <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-zinc-800 text-stone-800 dark:text-stone-100 rounded-2xl shadow-xl border border-stone-100 dark:border-zinc-700 py-2 z-50 animate-fadeIn">
                <button
                  onClick={() => {
                    setShowOverflow(false);
                    onOpenProfile();
                  }}
                  className="w-full px-4 py-3 text-sm text-left flex items-center gap-3 hover:bg-stone-50 dark:hover:bg-zinc-700/50 min-h-[44px]"
                >
                  <User className="w-4 h-4 text-stone-500" />
                  <span>{getTranslation(profile.language, 'teacherProfile')}</span>
                </button>

                <button
                  onClick={() => {
                    setShowOverflow(false);
                    onOpenProfile();
                  }}
                  className="w-full px-4 py-3 text-sm text-left flex items-center gap-3 hover:bg-stone-50 dark:hover:bg-zinc-700/50 min-h-[44px]"
                >
                  <Settings className="w-4 h-4 text-stone-500" />
                  <span>{getTranslation(profile.language, 'settings')}</span>
                </button>

                <button
                  onClick={() => {
                    setShowOverflow(false);
                    toggleDarkMode();
                  }}
                  className="w-full px-4 py-3 text-sm text-left flex items-center gap-3 hover:bg-stone-50 dark:hover:bg-zinc-700/50 min-h-[44px]"
                >
                  {profile.darkMode ? (
                    <>
                      <Sun className="w-4 h-4 text-amber-500" />
                      <span>Yorug' rejim (Light mode)</span>
                    </>
                  ) : (
                    <>
                      <Moon className="w-4 h-4 text-indigo-500" />
                      <span>Tungi rejim (Dark mode)</span>
                    </>
                  )}
                </button>

                <div className="my-1 border-t border-stone-100 dark:border-zinc-700" />

                <button
                  onClick={() => {
                    setShowOverflow(false);
                    if (confirm("Chiqishni xohlaysizmi?")) {
                      onUpdateProfile({ isFirstLaunchCompleted: false });
                    }
                  }}
                  className="w-full px-4 py-3 text-sm text-left flex items-center gap-3 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 min-h-[44px]"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{getTranslation(profile.language, 'signOut')}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

