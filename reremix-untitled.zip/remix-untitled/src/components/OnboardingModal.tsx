import React, { useState } from 'react';
import { AppLanguage, ThemeColor } from '../types';
import { themeConfigs } from '../lib/theme';
import { getTranslation } from '../lib/translations';
import { Check, Sparkles, Languages, Palette, ArrowRight } from 'lucide-react';

interface OnboardingModalProps {
  currentLang: AppLanguage;
  currentTheme: ThemeColor;
  onComplete: (lang: AppLanguage, theme: ThemeColor) => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  currentLang,
  currentTheme,
  onComplete,
}) => {
  const [step, setStep] = useState<1 | 2>(1); // Step 1 = Language, Step 2 = Theme
  const [selectedLang, setSelectedLang] = useState<AppLanguage>(currentLang);
  const [selectedTheme, setSelectedTheme] = useState<ThemeColor>(currentTheme);

  const themeList: ThemeColor[] = [
    'forest_green',
    'trust_blue',
    'violet',
    'warm_rose',
    'teal',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[#FFFBF7] dark:bg-zinc-900 border border-amber-100/50 dark:border-zinc-800 rounded-3xl shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-6 transition-all duration-300">
        
        {/* Step Indicator */}
        <div className="flex items-center justify-between border-b border-stone-200 dark:border-zinc-800 pb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center text-emerald-700 dark:text-emerald-300 font-bold text-sm">
              {step}
            </div>
            <span className="text-sm font-semibold text-stone-600 dark:text-stone-300">
              {step === 1 ? '1/2 — Language' : '2/2 — Theme Color'}
            </span>
          </div>
          <div className="flex gap-1.5">
            <div className={`w-3 h-1.5 rounded-full ${step >= 1 ? 'bg-emerald-600' : 'bg-stone-200 dark:bg-zinc-800'}`} />
            <div className={`w-3 h-1.5 rounded-full ${step === 2 ? 'bg-emerald-600' : 'bg-stone-200 dark:bg-zinc-800'}`} />
          </div>
        </div>

        {/* STEP 1: Language Selection */}
        {step === 1 && (
          <div className="space-y-6 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="mx-auto w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-amber-700 dark:text-amber-400 mb-3">
                <Languages className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold font-display text-stone-900 dark:text-white">
                {getTranslation(selectedLang, 'selectLanguageTitle')}
              </h2>
              <p className="text-sm text-stone-500 dark:text-stone-400">
                {getTranslation(selectedLang, 'selectLanguageSub')}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {[
                { code: 'uz' as AppLanguage, label: "O'zbekcha", flag: "🇺🇿", detail: "O'zbek tili (Boshlang'ich)" },
                { code: 'ru' as AppLanguage, label: 'Русский', flag: '🇷🇺', detail: 'Русский язык' },
                { code: 'en' as AppLanguage, label: 'English', flag: '🇬🇧', detail: 'English language' },
              ].map((item) => {
                const isSelected = selectedLang === item.code;
                return (
                  <button
                    key={item.code}
                    onClick={() => setSelectedLang(item.code)}
                    className={`w-full min-h-[56px] px-5 py-4 rounded-2xl border-2 flex items-center justify-between text-left transition-all duration-200 active:scale-[0.99] ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/60 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-200 shadow-sm'
                        : 'border-stone-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/80 text-stone-800 dark:text-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{item.flag}</span>
                      <div>
                        <div className="font-semibold text-base">{item.label}</div>
                        <div className="text-xs text-stone-500 dark:text-stone-400">{item.detail}</div>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                        <Check className="w-4 h-4" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full h-14 bg-stone-900 hover:bg-stone-800 dark:bg-white dark:hover:bg-stone-100 text-white dark:text-stone-900 font-semibold text-base rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] min-h-[52px]"
            >
              <span>{getTranslation(selectedLang, 'continue')}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* STEP 2: Theme Selection (Live Preview Cards) */}
        {step === 2 && (
          <div className="space-y-6 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="mx-auto w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-700 dark:text-indigo-400 mb-3">
                <Palette className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold font-display text-stone-900 dark:text-white">
                {getTranslation(selectedLang, 'selectThemeTitle')}
              </h2>
              <p className="text-sm text-stone-500 dark:text-stone-400">
                {getTranslation(selectedLang, 'selectThemeSub')}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3 max-h-[360px] overflow-y-auto pr-1">
              {themeList.map((tCode) => {
                const config = themeConfigs[tCode];
                const isSelected = selectedTheme === tCode;
                const themeName = getTranslation(selectedLang, config.nameKey as any);

                return (
                  <button
                    key={tCode}
                    onClick={() => setSelectedTheme(tCode)}
                    className={`w-full p-4 rounded-2xl border-2 text-left transition-all duration-200 active:scale-[0.99] min-h-[56px] ${
                      isSelected
                        ? 'border-stone-900 dark:border-white shadow-md bg-stone-50 dark:bg-zinc-800/90'
                        : 'border-stone-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/40 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2 font-bold text-sm text-stone-900 dark:text-white">
                        <div
                          className="w-4 h-4 rounded-full shadow-inner"
                          style={{ backgroundColor: config.primary }}
                        />
                        <span>{themeName}</span>
                      </div>
                      {isSelected && (
                        <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-stone-900 text-white dark:bg-white dark:text-stone-900">
                          Selected
                        </span>
                      )}
                    </div>

                    {/* Miniature Live Preview of Header + Stat Card */}
                    <div className="rounded-xl overflow-hidden shadow-sm border border-stone-200/60 dark:border-zinc-700/50">
                      <div
                        className="p-3 text-white text-xs font-semibold flex justify-between items-center"
                        style={{
                          background: `linear-gradient(135deg, ${config.primary}, ${config.gradientEnd})`,
                        }}
                      >
                        <span>Dashboard Preview</span>
                        <Sparkles className="w-3.5 h-3.5 opacity-80" />
                      </div>
                      <div className="p-2.5 bg-[#FFFBF7] dark:bg-zinc-900 flex gap-2">
                        <div className="flex-1 bg-white dark:bg-zinc-800 p-2 rounded-lg shadow-sm border border-stone-100 dark:border-zinc-700">
                          <div className="text-[10px] text-stone-400">Class Avg</div>
                          <div className="font-bold text-xs text-stone-800 dark:text-stone-100">8.8 / 10</div>
                        </div>
                        <div className="flex-1 bg-white dark:bg-zinc-800 p-2 rounded-lg shadow-sm border border-stone-100 dark:border-zinc-700">
                          <div className="text-[10px] text-stone-400">Completion</div>
                          <div className="font-bold text-xs" style={{ color: config.primary }}>
                            94%
                          </div>
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setStep(1)}
                className="flex-1 h-14 bg-stone-200 hover:bg-stone-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-stone-800 dark:text-stone-200 font-semibold text-base rounded-2xl transition-all active:scale-[0.98] min-h-[52px]"
              >
                Back
              </button>
              <button
                onClick={() => onComplete(selectedLang, selectedTheme)}
                className="flex-[2] h-14 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-base rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] min-h-[52px]"
              >
                <span>{getTranslation(selectedLang, 'startApp')}</span>
                <Check className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
