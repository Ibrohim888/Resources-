import { ThemeColor, AppLanguage } from '../types';
import { getTranslation } from './translations';

export interface ThemeConfig {
  nameKey: 'forest_green' | 'trust_blue' | 'violet' | 'warm_rose' | 'teal';
  primary: string;
  gradientEnd: string;
  bgLight: string;
  cardLight: string;
  primaryLight: string;
  badgeBg: string;
  badgeText: string;
}

export const themeConfigs: Record<ThemeColor, ThemeConfig> = {
  forest_green: {
    nameKey: 'forest_green',
    primary: '#2E8B7A',
    gradientEnd: '#4CAF9E',
    bgLight: '#FFFBF7',
    cardLight: '#FFFFFF',
    primaryLight: '#E6F4F1',
    badgeBg: '#E3F6E9',
    badgeText: '#2E9E56',
  },
  trust_blue: {
    nameKey: 'trust_blue',
    primary: '#3D6BC7',
    gradientEnd: '#5B87E0',
    bgLight: '#FFFBF7',
    cardLight: '#FFFFFF',
    primaryLight: '#EBF1FA',
    badgeBg: '#E3F6E9',
    badgeText: '#2E9E56',
  },
  violet: {
    nameKey: 'violet',
    primary: '#6B5CD9',
    gradientEnd: '#8B7BE8',
    bgLight: '#FFFBF7',
    cardLight: '#FFFFFF',
    primaryLight: '#EEECFB',
    badgeBg: '#E3F6E9',
    badgeText: '#2E9E56',
  },
  warm_rose: {
    nameKey: 'warm_rose',
    primary: '#D6577A',
    gradientEnd: '#E87A98',
    bgLight: '#FFFBF7',
    cardLight: '#FFFFFF',
    primaryLight: '#FCEBF0',
    badgeBg: '#E3F6E9',
    badgeText: '#2E9E56',
  },
  teal: {
    nameKey: 'teal',
    primary: '#1E9B8A',
    gradientEnd: '#17B8A6',
    bgLight: '#FFFBF7',
    cardLight: '#FFFFFF',
    primaryLight: '#E3F8F5',
    badgeBg: '#E3F6E9',
    badgeText: '#2E9E56',
  },
};

/**
 * Generates an 8-digit numeric ID for students (e.g. "84920184")
 * consisting ONLY of numbers.
 */
export function generateStudentIdNumber(): string {
  return Math.floor(10000000 + Math.random() * 90000000).toString();
}

/**
 * Generates an 8-character uppercase alphanumeric secret code for students
 * consisting of mixed letters and numbers (e.g. "TX78B2A9").
 */
export function generateStudentSecretCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Formats or converts grades into qualitative performance labels:
 * 10 / 90-100% -> Excellent
 * 8-9 / 70-89% -> Good
 * 6-7 / 50-69% -> Average
 * 0-5 / 0-49%  -> Poor
 */
export function getQualitativeGradeLabel(grade: number | null, lang: AppLanguage): { label: string; colorClass: string } {
  if (grade === null || grade === undefined) {
    return { label: '-', colorClass: 'text-gray-400' };
  }
  
  // Normalize to 0-10 scale
  const normalized = grade > 10 ? grade / 10 : grade;

  if (normalized >= 9) {
    return {
      label: getTranslation(lang, 'qualitativeExcellent'),
      colorClass: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
    };
  } else if (normalized >= 7) {
    return {
      label: getTranslation(lang, 'qualitativeGood'),
      colorClass: 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300'
    };
  } else if (normalized >= 5) {
    return {
      label: getTranslation(lang, 'qualitativeAverage'),
      colorClass: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
    };
  } else {
    return {
      label: getTranslation(lang, 'qualitativePoor'),
      colorClass: 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300'
    };
  }
}
