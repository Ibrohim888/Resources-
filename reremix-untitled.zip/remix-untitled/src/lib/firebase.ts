import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyAlpQ5qO9P3q7KxmVR0Fxfz2BL6QzjG0c8",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "homework-manager-fe294.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "homework-manager-fe294",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "homework-manager-fe294.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "1033626297483",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:1033626297483:web:77a3621b4178ec7a7e608e"
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app);
export const auth = getAuth(app);
export default app;
