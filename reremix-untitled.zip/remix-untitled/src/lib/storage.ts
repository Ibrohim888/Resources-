import {
  TeacherProfile,
  Student,
  Homework,
  Result,
  MonthlyArchive,
  AppLanguage,
  ThemeColor
} from '../types';
import { generateStudentIdNumber, generateStudentSecretCode } from './theme';
import { db } from './firebase';
import { doc, setDoc } from 'firebase/firestore';

const PROFILE_KEY = 'thm_teacher_profile';
const STUDENTS_KEY = 'thm_students';
const HOMEWORKS_KEY = 'thm_homeworks';
const RESULTS_KEY = 'thm_results';
const ARCHIVES_KEY = 'thm_monthly_archives';

// Helper for non-blocking Firestore sync to both app_data and dedicated collections for external apps (e.g. Student App)
async function syncToFirebase(docKey: string, data: any) {
  try {
    // 1. Array/Object document in app_data collection
    const docRef = doc(db, 'app_data', docKey);
    await setDoc(docRef, { data, updatedAt: Date.now() });

    // 2. Individual documents in dedicated collections for Student App & external integrations
    if (docKey === 'students' && Array.isArray(data)) {
      for (const student of data) {
        if (student && student.id) {
          await setDoc(doc(db, 'students', student.id), {
            ...student,
            updatedAt: Date.now()
          });
        }
      }
    } else if (docKey === 'homeworks' && Array.isArray(data)) {
      for (const hw of data) {
        if (hw && hw.id) {
          await setDoc(doc(db, 'homeworks', hw.id), {
            ...hw,
            updatedAt: Date.now()
          });
        }
      }
    } else if (docKey === 'results' && Array.isArray(data)) {
      for (const res of data) {
        if (res && res.id) {
          await setDoc(doc(db, 'results', res.id), {
            ...res,
            updatedAt: Date.now()
          });
        }
      }
    } else if (docKey === 'archives' && Array.isArray(data)) {
      for (const arch of data) {
        if (arch && arch.id) {
          await setDoc(doc(db, 'monthly_archives', arch.id), {
            ...arch,
            updatedAt: Date.now()
          });
        }
      }
    } else if (docKey === 'profile' && data) {
      await setDoc(doc(db, 'profiles', 'main_teacher'), {
        ...data,
        updatedAt: Date.now()
      });
    }
  } catch (err) {
    // Silent catch for offline or permission pending states
    console.debug(`Firebase sync for ${docKey}:`, err);
  }
}

export async function syncReport3LanguagesToFirebase(reportData: {
  monthLabel: string;
  centerName: string;
  teacherName: string;
  studentsCount: number;
  homeworksCount: number;
  rankings: Array<{
    studentId: string;
    studentName: string;
    studentIdNumber: string;
    secretCode: string;
    classNames: string[];
    avgGrade: number;
    completionRate: number;
  }>;
}) {
  try {
    const reportId = `report_${reportData.monthLabel.replace('-', '_')}`;
    const reportDocRef = doc(db, 'reports', reportId);

    const fullReport3Lang = {
      id: reportId,
      monthLabel: reportData.monthLabel,
      generatedAt: Date.now(),
      centerName: reportData.centerName,
      teacherName: reportData.teacherName,
      stats: {
        totalStudents: reportData.studentsCount,
        totalHomeworks: reportData.homeworksCount,
      },
      reports: {
        uz: {
          title: `${reportData.monthLabel} - Oylik Reyting va Baholar Hisoboti`,
          center: reportData.centerName,
          teacher: reportData.teacherName,
          summary: `Ushbu oyda ${reportData.studentsCount} ta o'quvchi va ${reportData.homeworksCount} ta uy vazifasi bo'yicha baholar shakllantirildi.`,
          top3Notice: reportData.rankings.length > 0
            ? `Eng yuqori ball to'plagan 1-o'rin o'quvchisi: ${reportData.rankings[0].studentName} (${reportData.rankings[0].avgGrade.toFixed(1)} ball)`
            : ''
        },
        ru: {
          title: `${reportData.monthLabel} - Ежемесячный Рейтинг и Отчет об Оценках`,
          center: reportData.centerName,
          teacher: reportData.teacherName,
          summary: `В этом месяце сформированы оценки для ${reportData.studentsCount} учеников по ${reportData.homeworksCount} домашним заданиям.`,
          top3Notice: reportData.rankings.length > 0
            ? `1-е место с наивысшим баллом: ${reportData.rankings[0].studentName} (${reportData.rankings[0].avgGrade.toFixed(1)} баллов)`
            : ''
        },
        en: {
          title: `${reportData.monthLabel} - Monthly Rating and Grade Report`,
          center: reportData.centerName,
          teacher: reportData.teacherName,
          summary: `This month, grades were generated for ${reportData.studentsCount} students across ${reportData.homeworksCount} homework assignments.`,
          top3Notice: reportData.rankings.length > 0
            ? `1st place top performer: ${reportData.rankings[0].studentName} (${reportData.rankings[0].avgGrade.toFixed(1)} pts)`
            : ''
        }
      },
      rankings: reportData.rankings
    };

    await setDoc(reportDocRef, fullReport3Lang);
    console.log(`Synced 3-language report to Firebase Firestore: ${reportId}`);
  } catch (err) {
    console.debug("Firebase sync for 3-language report error:", err);
  }
}


export const DEFAULT_PROFILE: TeacherProfile = {
  fullName: 'Zilola Alimova',
  email: 'zilola.teacher@gmail.com',
  centerName: 'Registon O\'quv Markazi',
  language: 'uz',
  themeColor: 'forest_green',
  themeMode: 'system',
  darkMode: false,
  ratingStartDate: 1,
  isFirstLaunchCompleted: false, // Set to false so first launch triggers mandatory language & theme picker!
};

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'st_1',
    studentIdNumber: '84920184',
    secretCode: 'TX78B2A9',
    firstName: 'Jahongir',
    lastName: 'Toirov',
    fullName: 'Jahongir Toirov',
    classNames: ['7-A', 'Matematika Group'],
    phone: '+998901234567',
    notes: 'Aktiv va tirishqoq o\'quvchi',
    createdAt: Date.now() - 30 * 86400000,
    isActive: true,
  },
  {
    id: 'st_2',
    studentIdNumber: '71029384',
    secretCode: 'MK92P4L7',
    firstName: 'Aziza',
    lastName: 'Karimova',
    fullName: 'Aziza Karimova',
    classNames: ['7-A', 'Ingliz tili 1'],
    phone: '+998912345678',
    notes: 'Vazifalarni vaqtida topshiradi',
    createdAt: Date.now() - 28 * 86400000,
    isActive: true,
  },
  {
    id: 'st_3',
    studentIdNumber: '92837410',
    secretCode: 'RK88N1V3',
    firstName: 'Shahzod',
    lastName: 'Murodov',
    fullName: 'Shahzod Murodov',
    classNames: ['8-B', 'Matematika Group'],
    phone: '+998933456789',
    notes: 'Matematikadan iqtidori yuqori',
    createdAt: Date.now() - 25 * 86400000,
    isActive: true,
  },
  {
    id: 'st_4',
    studentIdNumber: '54129837',
    secretCode: 'PL34Q9W2',
    firstName: 'Malika',
    lastName: 'Rashidova',
    fullName: 'Malika Rashidova',
    classNames: ['7-A', 'Olimpiada Group'],
    phone: '+998944567890',
    notes: 'Olimpiadaga tayyorgarlik ko\'rmoqda',
    createdAt: Date.now() - 20 * 86400000,
    isActive: true,
  },
  {
    id: 'st_5',
    studentIdNumber: '63920184',
    secretCode: 'ZH51X6M8',
    firstName: 'Bekzod',
    lastName: 'Rahimov',
    fullName: 'Bekzod Rahimov',
    classNames: ['8-B', 'Fizika Group'],
    phone: '+998975678901',
    notes: 'Qo\'shimcha mashqlar berish kerak',
    createdAt: Date.now() - 15 * 86400000,
    isActive: true,
  },
  {
    id: 'st_6',
    studentIdNumber: '38492017',
    secretCode: 'GT19Y3K4',
    firstName: 'Gulnora',
    lastName: 'Toshmatova',
    fullName: 'Gulnora Toshmatova',
    classNames: ['7-A', 'Matematika Group'],
    phone: '+998996789012',
    notes: 'Muntazam darsga qatnashadi',
    createdAt: Date.now() - 10 * 86400000,
    isActive: true,
  },
];

export const INITIAL_HOMEWORKS: Homework[] = [
  {
    id: 'hw_1',
    title: 'Kvadrat tenglamalar va Viyet teoremasi',
    subject: 'Matematika',
    className: '7-A',
    description: 'Darslikdagi 120-125 mashqlarni yechish va formulalarni yodlash.',
    assignedDate: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0],
    deadline: new Date(Date.now() + 1 * 86400000).toISOString().split('T')[0],
    status: 'ACTIVE',
    createdAt: Date.now() - 2 * 86400000,
    updatedAt: Date.now() - 2 * 86400000,
  },
  {
    id: 'hw_2',
    title: 'Present Perfect vs Past Simple Exercise',
    subject: 'Ingliz tili',
    className: '7-A',
    description: 'Write 10 sentences comparing Present Perfect and Past Simple tenses.',
    assignedDate: new Date(Date.now() - 5 * 86400000).toISOString().split('T')[0],
    deadline: new Date(Date.now() - 1 * 86400000).toISOString().split('T')[0],
    status: 'COMPLETED',
    createdAt: Date.now() - 5 * 86400000,
    updatedAt: Date.now() - 1 * 86400000,
  },
  {
    id: 'hw_3',
    title: 'Nyutonning ikkinchi qonuni va masalalar',
    subject: 'Fizika',
    className: '8-B',
    description: 'Kuch va tezlanish bog\'liqligi bo\'yicha 4 ta masala yechish.',
    assignedDate: new Date().toISOString().split('T')[0],
    deadline: new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
    status: 'ACTIVE',
    createdAt: Date.now(),
    updatedAt: Date.now(),
  },
];

export const INITIAL_RESULTS: Result[] = [
  {
    id: 'res_1',
    studentId: 'st_1',
    homeworkId: 'hw_1',
    isPresent: true,
    completionStatus: 'COMPLETED',
    grade: 10,
    gradeType: 'POINT_10',
    comment: 'A\'lo darajada bajarilgan!',
    checkedDate: Date.now() - 86400000,
    checkedBy: 'Zilola Alimova',
  },
  {
    id: 'res_2',
    studentId: 'st_2',
    homeworkId: 'hw_1',
    isPresent: true,
    completionStatus: 'PARTIAL',
    grade: 7,
    gradeType: 'POINT_10',
    comment: 'Ba\'zi xatolar bor, qayta ko\'ring',
    checkedDate: Date.now() - 86400000,
    checkedBy: 'Zilola Alimova',
  },
  {
    id: 'res_3',
    studentId: 'st_4',
    homeworkId: 'hw_1',
    isPresent: true,
    completionStatus: 'COMPLETED',
    grade: 10,
    gradeType: 'POINT_10',
    comment: 'Tugallangan',
    checkedDate: Date.now() - 86400000,
    checkedBy: 'Zilola Alimova',
  },
  {
    id: 'res_4',
    studentId: 'st_6',
    homeworkId: 'hw_1',
    isPresent: false, // Absent (NB)
    completionStatus: 'MISSING',
    grade: 0,
    gradeType: 'POINT_10',
    comment: 'Darsga kelmadi',
    checkedDate: Date.now() - 86400000,
    checkedBy: 'Zilola Alimova',
  },
];

export function getStoredProfile(): TeacherProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) return DEFAULT_PROFILE;
    const parsed = JSON.parse(raw);
    if (!parsed.themeMode) {
      parsed.themeMode = parsed.darkMode ? 'dark' : 'system';
    }
    return parsed;
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function saveProfile(profile: TeacherProfile): void {
  localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  syncToFirebase('profile', profile);
}

export function getStoredStudents(): Student[] {
  try {
    const raw = localStorage.getItem(STUDENTS_KEY);
    if (!raw) {
      localStorage.setItem(STUDENTS_KEY, JSON.stringify(INITIAL_STUDENTS));
      syncToFirebase('students', INITIAL_STUDENTS);
      return INITIAL_STUDENTS;
    }
    const parsed: Student[] = JSON.parse(raw);
    let changed = false;
    const updated = parsed.map((s) => {
      let newS = { ...s };
      if (!newS.studentIdNumber || !/^\d{8}$/.test(newS.studentIdNumber)) {
        newS.studentIdNumber = generateStudentIdNumber();
        changed = true;
      }
      if (!newS.secretCode || /^\d{8}$/.test(newS.secretCode) || newS.secretCode.length !== 8) {
        newS.secretCode = generateStudentSecretCode();
        changed = true;
      }
      return newS;
    });
    if (changed) {
      localStorage.setItem(STUDENTS_KEY, JSON.stringify(updated));
      syncToFirebase('students', updated);
    }
    return updated;
  } catch {
    return INITIAL_STUDENTS;
  }
}

export function saveStudents(students: Student[]): void {
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(students));
  syncToFirebase('students', students);
}

export function getStoredHomeworks(): Homework[] {
  try {
    const raw = localStorage.getItem(HOMEWORKS_KEY);
    if (!raw) {
      localStorage.setItem(HOMEWORKS_KEY, JSON.stringify(INITIAL_HOMEWORKS));
      syncToFirebase('homeworks', INITIAL_HOMEWORKS);
      return INITIAL_HOMEWORKS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_HOMEWORKS;
  }
}

export function saveHomeworks(homeworks: Homework[]): void {
  localStorage.setItem(HOMEWORKS_KEY, JSON.stringify(homeworks));
  syncToFirebase('homeworks', homeworks);
}

export function getStoredResults(): Result[] {
  try {
    const raw = localStorage.getItem(RESULTS_KEY);
    if (!raw) {
      localStorage.setItem(RESULTS_KEY, JSON.stringify(INITIAL_RESULTS));
      syncToFirebase('results', INITIAL_RESULTS);
      return INITIAL_RESULTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_RESULTS;
  }
}

export function saveResults(results: Result[]): void {
  localStorage.setItem(RESULTS_KEY, JSON.stringify(results));
  syncToFirebase('results', results);
}

export function getStoredArchives(): MonthlyArchive[] {
  try {
    const raw = localStorage.getItem(ARCHIVES_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveArchives(archives: MonthlyArchive[]): void {
  localStorage.setItem(ARCHIVES_KEY, JSON.stringify(archives));
  syncToFirebase('archives', archives);
}
